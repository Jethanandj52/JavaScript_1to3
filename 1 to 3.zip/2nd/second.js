
// first
var username;

// second
var myName="Jethanand"
document.write("<b>Question 2 </b><br><br>"+myName);

// third
var message="Hellow World";
alert("Question 3 \n"+message);

// fourth
var fullName='Jhone Doe'
var age='15 years old'
var qualify='Certified Mobile Application Development'

alert("Question 4.1 \n"+fullName);
alert("Question 4.2 \n"+age)
alert("Question 4.3 \n"+qualify)

// fifth
var foodName='Pizza \n Pizz \n Piz \n Pi \n P'
alert("Question 5 \n"+foodName)

// sixth
var gmail='example.@gmail.com'
alert('Question 6 \nMy email address is '+gmail)

// seventh
var book="A smarter way to learn JavaScript"
 alert('Question 7 \nI am trying to learn from the book '+book)
 
// eighth
var content='Yah! I can write HTML content through JavaScript'
document.write("<br> <b>Question 8 </b><br><br>"+content+"<br>")

// ninth
var symbol='▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬'
alert("Question 9 \n"+symbol)