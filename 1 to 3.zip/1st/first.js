// first question
alert("Question 1 \nWelcome Jethanand in SMIT")

// second Question
alert("Question 2 \nError! Please enter a valid password ")

// thrid question
alert(" Question 3 \nWelcome to JS Land...\n Happy Coding!")

// fourth question
alert("Question 3.1 \nWelcome to JS Land...")
alert("Question 3.2 \nHappy Coding! \n Prevent this page from creating additional dialogs.")

// fifth question
document.write(" <b>Question 1 </b><br><br>Hello... I can run JS through my web browser's console");

// sixth question
alert("Question 6 \nWelcome... Jethanand To Learn JavaScript");


