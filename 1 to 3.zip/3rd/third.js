
// first
var age=15;
 var ageString='I am '
 var ageString2=" Years old"

 alert("Question 1 \n"+ageString+age+ageString2)

// second

// third
var birhtYear=22
document.write('"<b>Question 3 </b><br><br>"+My birth year is ' +birhtYear+'<br>Data type of my declared varaible is number<br>')

// fourth
var vistorName="John Doe";
var productTitle='T-shirt';
var quantity=5;
document.write( "<b>Question 4 </b><br><br> "+vistorName+' ordered '+quantity+' '+productTitle+'(s) on XYZ Clothing store');